#include "timeDriver.h"
#include "timeDriverASM.h"
#include "videoDriver.h"

void _sti();

static unsigned long ticks = 0;
Color w ={255, 255, 255};


void timeHandler() {
	ticks++;
	//printChar((ticks%10)+48, w);
	/*Color w = {255, 255, 255};
	printChar((ticks%10) + 48, w);*/
}

int ticksElapsed() {
	return ticks;	
}


void wait(int n) {
	_sti();
	int t = ticksElapsed() + n;
	while(ticksElapsed() < t);

}

unsigned int getHour() {
	unsigned int t = _getHour();
	return t;
}

unsigned int getMinute() {
	unsigned int t = _getMinute();
	return t;
}

unsigned int getSecond() {
	unsigned int t = _getSecond();
	return t;
}