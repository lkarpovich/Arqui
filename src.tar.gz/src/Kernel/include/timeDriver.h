#ifndef TIMEDriver_h
#define TIMEDriver_h

void timeHandler();
int ticksElapsed();
unsigned int getHour();
unsigned int getMinute();
unsigned int getSecond();

#endif