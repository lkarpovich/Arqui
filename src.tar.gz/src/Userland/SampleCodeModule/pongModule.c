/*#include "pongModule.h"
#include "videoModule.h"
#include "stdlib.h"
#include "timeModule.h"

void startPong() {
	Player p1;
	Player p2;
	Ball ball;
	printInitScreen(p1, p2, ball);
	Player winner = play(p1, p2, ball);
	printWinScreen(winner);
	return;
}

void printInitScreen(p1, p2, ball) {
	
}*/