#ifndef systemCall_h
#define systemCall_h
#include <stdint.h>

#define READ 0
#define WRITE 1

#define KEY 0
#define TIME 1

#define CHARACTER 0
#define DRAWCHAR 1
#define CLEAR 2
#define PAINT 3
#define BALL 4
#define RECTANGLE 5

#define HOUR 0
#define MINUTE 1
#define SECOND 2

#define BUFFER_SIZE 256

typedef struct Color{
		uint8_t red;
		uint8_t green;
		uint8_t blue;
} Color;

unsigned int systemCall(uint64_t syscall, uint64_t p1, uint64_t p2, uint64_t p3, uint64_t p4, uint64_t p5);

#endif
