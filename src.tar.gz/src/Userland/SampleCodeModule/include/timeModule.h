#ifndef TIMEMODULE_H
#define TIMEMODULE_H

unsigned int getHour();

unsigned int getMinute();

unsigned int getSecond();

#endif