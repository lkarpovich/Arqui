//#include "videoModule.h"
#include "SYSCall.h"
#include "stdint.h"

void clearScreen() {
	systemCall((uint64_t)WRITE, (uint64_t)CLEAR, 0, 0, 0, 0);
}

void deleteChar() {
	char d = '\b';
	systemCall((uint64_t)WRITE, (uint64_t)CHARACTER,(uint64_t) &d, 0, 0, 0);
}

void drawBall(int radio, int x, int y){
	Color white = {255, 255, 255};
	int num = 100;
	systemCall((uint64_t)WRITE, (uint64_t)BALL, (uint64_t)&radio, (uint64_t) &white, (uint64_t)&x, (uint64_t)&y);
}

void drawRectangle(){
	Color white = {255, 255, 255};
	int num = 100;
	systemCall((uint64_t)WRITE, (uint64_t)RECTANGLE, (uint64_t)&num, (uint64_t) &white, (uint64_t)&num, (uint64_t)&num);
}
