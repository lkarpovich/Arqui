#ifndef TEST_H
#define TEST_H

void paramT();
void param(int a, int b, int c, int d, int e, int f, int g);
void paramTest(int a, int b, int c, int d, int e, int f, int g);

#endif